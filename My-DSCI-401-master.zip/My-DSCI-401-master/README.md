# DSCI 401
Course Repo for DSCI 401 *(Applied Machine Learning)* at UMW - **Spring 2019**
